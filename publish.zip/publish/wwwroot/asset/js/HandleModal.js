﻿$(document).on("click", "#overlay-confirm", function () {
    $("#content-modal-confirm-report").html("");
})